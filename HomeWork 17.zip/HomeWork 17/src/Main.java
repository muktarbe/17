// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        System.out.println(" ");
        Triangle triangle = new Triangle(5,4,4);
        System.out.print(" периметор вашего треуголника равна = ");
        triangle.getPerimeter();
        System.out.println("=====================================");

        Rhomb rhomb = new Rhomb(5);
        System.out.print(" периметор вашего ромбика равна = ");
        rhomb.getPerimeter();
        System.out.println("=====================================");

        Rectangle rectangle = new Rectangle(5,2);
        System.out.print(" периметор вашего прямоугольника равна = ");
        rectangle.getPerimeter();
        System.out.println("=====================================");

        Square square = new Square(2);
        System.out.print(" периметор вашего квадрата равна = ");
        square.getPerimeter();
        System.out.println("=====================================");

        Hexagon hexagon = new Hexagon(3);
        System.out.print(" периметор вашего щестиугольника равна = ");
        hexagon.getPerimeter();

    }
}