public class Square extends Shape{  //Квадрат
    int s;

    public Square(int s) {
        this.s = s;
    }

    @Override
    public void getPerimeter() {
        int a = s*4;
        System.out.println(a);
    }
}
