public class Hexagon extends Shape{  //Шестиугольник
    private int s;

    public Hexagon(int s) {
        this.s = s;
    }

    @Override
    public void getPerimeter() {
        int aa = s*6;
        System.out.println(aa);
    }
}
