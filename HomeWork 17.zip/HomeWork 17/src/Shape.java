public abstract class Shape {
    public abstract void getPerimeter ();

    }

