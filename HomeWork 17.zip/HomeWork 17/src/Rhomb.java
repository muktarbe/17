public class Rhomb extends Shape{  //Ромбик
    public  int a;

    public Rhomb(int a) {
        this.a = a;
    }

    @Override
    public void getPerimeter() {
        int aa = a*4;
        System.out.println(aa);
    }
}
