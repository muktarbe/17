public class Rectangle extends  Shape{  //Прямоугольник
    private int a1;
    private int a2;

    public Rectangle(int a1, int a2) {
        this.a1 = a1;
        this.a2 = a2;
    }

    @Override
    public void getPerimeter() {
        int aa = a1+a2+a1+a2;
        System.out.println(aa);
    }
}
